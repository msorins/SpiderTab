self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bf168db0fbbe9bfbdd96de319ab1132d",
    "url": "./index.html"
  },
  {
    "revision": "453b957f5dc27ae3e61a",
    "url": "./static/css/2.edb8eddf.chunk.css"
  },
  {
    "revision": "d28b0212a052702e422c",
    "url": "./static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "453b957f5dc27ae3e61a",
    "url": "./static/js/2.28f5aebd.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "./static/js/2.28f5aebd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d28b0212a052702e422c",
    "url": "./static/js/main.d3fb7dfa.chunk.js"
  },
  {
    "revision": "49fc73929b22ef8424e0",
    "url": "./static/js/runtime-main.4df6358e.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);