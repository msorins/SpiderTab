self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2fe2eca052712a74756b3c4d1f956c15",
    "url": "./index.html"
  },
  {
    "revision": "ea5dc6e41a86f8cb4a3b",
    "url": "./static/css/2.edb8eddf.chunk.css"
  },
  {
    "revision": "c52c84457a975d7c07d6",
    "url": "./static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "ea5dc6e41a86f8cb4a3b",
    "url": "./static/js/2.e62263d8.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "./static/js/2.e62263d8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c52c84457a975d7c07d6",
    "url": "./static/js/main.f24e0bbc.chunk.js"
  },
  {
    "revision": "49fc73929b22ef8424e0",
    "url": "./static/js/runtime-main.4df6358e.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);